/**
 * @author v.lugovsky
 * created on 16.12.2015
 */
(function () {
  'use strict';

  angular.module('BlurAdmin.pages.payroll.masters')
    .controller('TimeMastersController', TimeMastersController);

  /** @ngInject */
  function TimeMastersController() {
   
    var vm = this;
   

  }

})();
