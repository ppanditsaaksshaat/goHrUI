
// /**
//  * @author v.lugovsky
//  * created on 16.12.2015
//  */
// (function () {
//     'use strict';

//     angular.module('BlurAdmin.pages.leave.appadd', [

//     ])
//         .config(routeConfig);

//     /** @ngInject */
//     function routeConfig($stateProvider) {
//         $stateProvider
//             .state('leave.applicationapproved.approvedapp', {
//                 url: '/:action/:pageId/:pkId/',
//                 templateUrl: 'app/pages/leave/applications/applicationapproved/applicationapproved.html',
//                 title: 'Employee Leave Application',
//                 controller: "ApprovedAppController",
//                 controllerAs: "approvedCtrl"
//             });

//         //$urlRouterProvider.when('/leave/application', '/leave/applications/25');
//     }

// })();


