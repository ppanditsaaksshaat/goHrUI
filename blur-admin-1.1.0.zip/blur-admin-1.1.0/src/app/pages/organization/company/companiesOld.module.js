
// /**
//  * @author v.lugovsky
//  * created on 16.12.2015
//  */
// (function () {
//   'use strict';

//   angular.module('BlurAdmin.pages.organization.general.companies', [])
//     .config(routeConfig);

//   /** @ngInject */
//   function routeConfig($stateProvider, $urlRouterProvider) {

//     $stateProvider
//       .state('organization.general.companies', {
//         url: '/companies',
//         // abstract: true,
//         templateUrl: 'app/pages/organization/general/companies/companies.html',
//         controller: "companiesController",
//         controllerAs: "tabCtrl",
//         title: 'Companies',
//         sidebarMeta: {
//           order: 1,
//           parent: 'organization.general'
//         },
//       })
//     //  $urlRouterProvider.when('/organization/masters','/organization/masters/location/34');
//   }

// })();
