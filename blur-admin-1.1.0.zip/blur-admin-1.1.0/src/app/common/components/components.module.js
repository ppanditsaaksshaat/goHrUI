/**
 * @author deepak.jain
 * created on 06/05/2017
 */
(function () {
  'use strict';

  angular.module('BlurAdmin.common.components',[]);

})();
