// /**
//  * @author deepak.jain
//  * created on 20.09.2017
//  */
// (function () {
//     'use strict';

//     angular.module('BlurAdmin.common.components')
//     .directive('fileBox', fileBox);
//     function fileBox($location, $state, $compile, $rootScope, $timeout, dialogModal, pageService,
//         editFormService, focus, $filter) {

//             return {
//                 restrict: 'E',
//                 templateUrl: 'app/common/components/fileBox/fileBox.html',
//                 require: ['^ngController', 'ngModel'],
//                 replace: true,
//                 scope: {
//                     page: '=ngModel'
//                 },
//                 controller: function ($scope, $timeout) {
    
//                 },
//                 link: function ($scope, elm, attrs, ctrl){

//                 }
//             }
//         }
// })