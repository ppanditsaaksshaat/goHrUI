 // describe("Select One Module For Test", function() {
// var appPage = require('../../e2e/Apps.Module.js')

//         it('should Open Employee Module', function () {
//         appPage.openApp(appPage.emp);
//         element(by.id('close-sidebar')).click();
//         browser.waitForAngular();
//     });
//     })
